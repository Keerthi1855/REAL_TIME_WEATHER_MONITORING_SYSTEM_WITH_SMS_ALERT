#include <LPC21XX.H>
#include "types2.h"
#include "i2c_defines.h"
#include "i2c.h"
#include "i2c_eeprom.h"
#include "lcd_1.h"
#include "rtc1.h"


u8 hr, min, sec;

void RTC_SetTime(void)
{
  i2c_eeprom_write(0X68,0X00,0x00);
  i2c_eeprom_write(0X68,0X01,0x20);
  i2c_eeprom_write(0X68,0X02,0x03);

  //i2c_eeprom_read(0X68,0X02);
  //i2c_eeprom_read(0X68,0X02);
  //i2c_eeprom_read(0X68,0X02);
}
  

void RTC_Display(void)
{
 hr=i2c_eeprom_read(0X68,0X02);
 lcd_data((hr/16)+48);
 lcd_data((hr%16)+48);
 lcd_data(':');

 min=i2c_eeprom_read(0X68,0X01);
 lcd_data((min/16)+48);
 lcd_data((min%16)+48);
 lcd_data(':');

 sec=i2c_eeprom_read(0X68,0X00);
 lcd_data((sec/16)+48);
 lcd_data((sec%16)+48);
}

