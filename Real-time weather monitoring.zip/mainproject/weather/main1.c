#include <LPC21xx.h>
#include <stdio.h>								                                                                            
#include "types2.h"
#include "spi1.h"
#include "mcp3204_1.h"
#include "spi_defines1.h"
#include "lcd_1.h"
#include "delay1.h"
#include "i2c_defines1.h"
#include "i2c1.h"
#include "i2c_eeprom1.h"
#include "UART0_1.h"
#include "rtc1.h"

int main()
{
 f32 temp;
 u32 sms_count =0 ;
 init_i2c();
 RTC_SetTime(); 
 Init_SPI0();
 UART0_CONFIG();
 lcd_init();
 lcd_scroll("REAL TIME WEATHER MONITORING SYSTEM");
 lcd_cmd(0x01);
 delay_ms(500);
 
	
 while(1)
 {
		
	  lcd_cmd(0x80);
	  str("TIME:");
	  RTC_Display(); 
	  
	  temp=Read_ADC_MCP3204(0);
	  lcd_cmd(0xC0);
	  str("TEMP:");
	  Float_display(temp);
	  lcd_cmd(0x94);
	  str("                    ");
	  lcd_cmd(0x94);
	  if(temp <= 15)
	  {
	  str("Temperature Low!");
	  delay_ms(1000);
	  }
	  else if(temp > 15 && temp <= 29) 
	  {
	  str("Temperature Normal!");
	  delay_ms(1000);
	  }
	  else if(temp >= 30)
	  {
	  str("Temperature High!");
	  delay_ms(1000);
	  }
	   if(temp >= 30 && sms_count<3)
    {
	     char msg[30];
       UART0_STR("AT\r");
       delay_ms(1000);
       UART0_STR("AT+CMGF=1\r");
       delay_ms(1000);
       UART0_STR("AT+CMGS=\"+916380962556\"\r");
       delay_ms(1000);
	     sprintf(msg, "TIME:%02X:%02X:%02X\r\n", hr, min, sec);
       UART0_STR(msg);
       sprintf(msg, "TEMP:%.2f C\r\n", temp);
       UART0_STR(msg);
       UART0_STR("Temperature High!\r\n");
	     if(temp >= 30)
	     {
	        lcd_cmd(0xD4);
				  str("                    ");
				  lcd_cmd(0xD4);
	        str("Alert message sent");
	     }
       UART0_TX(26); 
	     sms_count++;     
       delay_ms(5000);
		 }
	      if(temp < 30)
	   { 
	      sms_count =0;
	   }
	 }
 }




