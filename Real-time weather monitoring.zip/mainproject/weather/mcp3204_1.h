#ifndef __MCP3204_1_H__
#define __MCP3204_1_H__

#include "types2.h"

f32 Read_ADC_MCP3204(u8 channelNo);

#endif


