#ifndef RTC_H
#define RTC_H

#include "types2.h"

extern u8 hr;
extern u8 min;
extern u8 sec;

void RTC_Display(void);
void RTC_SetTime(void);

#endif

