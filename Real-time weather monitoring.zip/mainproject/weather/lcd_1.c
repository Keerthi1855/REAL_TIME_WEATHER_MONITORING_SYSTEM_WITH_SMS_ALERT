#include<LPC21xx.h>
#include "lcd_1.h"
#define lcd_d 0xf<<14
#define rs 1<<12
#define e 1<<13


typedef unsigned int U32;
typedef unsigned char U8;
typedef signed char S8;
typedef float F32;

void delay_milliseconds(U32 milliseconds)
{
   //T0CTCR=0X00;
    T0PR = 15000-1;
	T0TCR = 0X01;
	while(T0TC<milliseconds);
	T0TCR = 0x03;
	T0TCR = 0x00;
}

void lcd_cmd(U8 cmd)
{
	IOCLR0 = lcd_d;
	IOSET0 = (cmd&0xF0)<<10;
	IOCLR0 = rs;
	IOSET0 =e;
	delay_milliseconds(2);
	IOCLR0 =e;
	
	IOCLR0 = lcd_d;
	IOSET0 = (cmd&0x0F)<<14;
	IOCLR0 = rs;
	IOSET0 =e;
	delay_milliseconds(2);
	IOCLR0 =e;

}


void lcd_data(U8 d)
{
   IOCLR0 = lcd_d;
   IOSET0 = (d&0xF0)<<10;
   IOSET0 = rs;
   IOSET0 =e;
   delay_milliseconds(2);
   IOCLR0 =e;
   
   IOCLR0 = lcd_d;
   IOSET0 = (d&0x0F)<<14;
   IOSET0 = rs;
   IOSET0 =e;
   delay_milliseconds(2);
   IOCLR0 =e;

}


void lcd_init(void)
{
   IODIR0 |= lcd_d|rs|e;
   lcd_cmd(0x01);
   lcd_cmd(0x02);
   lcd_cmd(0x0c);
   lcd_cmd(0x28);
   lcd_cmd(0x80);

}


void str(U8 *s)
{

	while(*s)
	{
	  lcd_data(*s++);
	}
}


void lcd_integer(int n)
{

	S8 arr[5],i=0;
	if(n==0)
	  lcd_data('0');
	else
	{
	   if(n<0)
	   {
				 lcd_data('-');
				 n=-n;
	   }
	      while(n>0)
      	{
		     arr[i++]=n%10;
		     n=n/10;
        }
        for(--i;i>=0;i--)
   	      lcd_data(arr[i]+48);
  }
}

void Float_display(F32 f_val)
{
 U32 number;
 number = f_val;
 lcd_integer(number);
 lcd_data('.');
 number=(f_val-number)*100;
 lcd_integer(number);	
}

void lcd_scroll(U8 *str)
{
  int i,j;

  for(i=0;str[i]!= '\0';i++)
  {
    lcd_cmd(0x80);

	for(j=0; j<16; j++)
	{
	  if(str[i+j]!= '\0')
	  lcd_data(str[i+j]);
	  else
	  lcd_data(' ');
	 }
	 delay_milliseconds(100);
	 }

	 lcd_cmd(0x01);
}








