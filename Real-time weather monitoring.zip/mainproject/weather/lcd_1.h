#ifndef LCD_1_H
#define LCD_1_H 
void lcd_init(void);
void lcd_cmd(unsigned char);
void lcd_data(unsigned char); 
void str(unsigned char *);
void lcd_integer(int); 
void Float_display(float);
void lcd_scroll(unsigned char *); 
#endif

